FLEET SERVICE PLANNING & GARAGE MANAGEMENT SYSTEM
==================================================

This package contains the complete standalone production build of the
Fleet Service Planning and Garage Management web application.

HOW TO RUN ON YOUR OFFICE LAPTOP:
---------------------------------
Option 1: Python (pre-installed on almost all Mac, Linux, and Windows systems)
  1. Open a terminal / command prompt in this extracted folder.
  2. Navigate into the "app" folder:
     cd app
  3. Start a local server:
     python -m http.server 3000
     (or on Python 2: python -m SimpleHTTPServer 3000)
  4. Open your browser and go to:
     http://localhost:3000

Option 2: Node.js / npx
  1. Open a terminal in this extracted folder.
  2. Run:
     npx serve app -l 3000
  3. Open http://localhost:3000 in your browser.

Option 3: Direct Web Access (No unzipping or install needed!)
  If your office laptop blocks *.ai.studio, you can access the app directly on Google Cloud Run:
  https://ais-pre-iyqhwuff6umxkze256xsb4-115538851024.asia-east1.run.app
  (This URL ends in .run.app, which bypasses domain blocks targeting .ai.studio)
